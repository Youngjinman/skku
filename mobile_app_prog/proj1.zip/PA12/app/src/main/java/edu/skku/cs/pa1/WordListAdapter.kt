package edu.skku.cs.pa1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat

class WordListAdapter(val data:ArrayList<Word>, val answer:String, val context: Context): BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val generatedView = inflater.inflate(R.layout.word_list, null)

        val word1 = generatedView.findViewById<TextView>(R.id.textView)
        val word2 = generatedView.findViewById<TextView>(R.id.textView2)
        val word3 = generatedView.findViewById<TextView>(R.id.textView3)
        val word4 = generatedView.findViewById<TextView>(R.id.textView4)
        val word5 = generatedView.findViewById<TextView>(R.id.textView5)

        word1.text = data[p0].word[0].toString().uppercase()
        word2.text = data[p0].word[1].toString().uppercase()
        word3.text = data[p0].word[2].toString().uppercase()
        word4.text = data[p0].word[3].toString().uppercase()
        word5.text = data[p0].word[4].toString().uppercase()

        //val answerResult = checkAnswer(data[p0].toString(), answer)

        for(i in data[p0].word.toString().indices){
            if(data[p0].word[i] == answer[i]) {
                if (i == 0) {
                    word1.setBackgroundResource(R.color.background_strike)
                    word1.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
                }
                else if(i == 1) {
                    word2.setBackgroundResource(R.color.background_strike)
                    word2.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
                }
                else if(i == 2){
                    word3.setBackgroundResource(R.color.background_strike)
                    word3.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
                }
                else if(i == 3){
                    word4.setBackgroundResource(R.color.background_strike)
                    word4.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
                }
                else if(i == 4){
                    word5.setBackgroundResource(R.color.background_strike)
                    word5.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
                }
            }
            else if(answer.contains(data[p0].word[i])){
                if (i == 0) {
                    word1.setBackgroundResource(R.color.background_ball)
                    word1.setTextColor(ContextCompat.getColor(context, R.color.text_ball))
                }
                else if(i == 1) {
                    word2.setBackgroundResource(R.color.background_ball)
                    word2.setTextColor(ContextCompat.getColor(context, R.color.text_ball))
                }
                else if(i == 2){
                    word3.setBackgroundResource(R.color.background_ball)
                    word3.setTextColor(ContextCompat.getColor(context, R.color.text_ball))
                }
                else if(i == 3){
                    word4.setBackgroundResource(R.color.background_ball)
                    word4.setTextColor(ContextCompat.getColor(context, R.color.text_ball))
                }
                else if(i == 4){
                    word5.setBackgroundResource(R.color.background_ball)
                    word5.setTextColor(ContextCompat.getColor(context, R.color.text_ball))
                }
            }
            else {
                if (i == 0) {
                    word1.setBackgroundResource(R.color.background_out)
                    word1.setTextColor(ContextCompat.getColor(context, R.color.text_out))
                }
                else if (i == 1){
                    word2.setBackgroundResource(R.color.background_out)
                    word2.setTextColor(ContextCompat.getColor(context, R.color.text_out))
                }
                else if (i == 2){
                    word3.setBackgroundResource(R.color.background_out)
                    word3.setTextColor(ContextCompat.getColor(context, R.color.text_out))
                }
                else if (i == 3){
                    word4.setBackgroundResource(R.color.background_out)
                    word4.setTextColor(ContextCompat.getColor(context, R.color.text_out))
                }
                else if (i == 4){
                    word5.setBackgroundResource(R.color.background_out)
                    word5.setTextColor(ContextCompat.getColor(context, R.color.text_out))
                }
            }

        }

        return generatedView
    }

}