package edu.skku.cs.pa1

class Word (
    val word: String
)
{
}