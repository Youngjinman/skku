package edu.skku.cs.pa1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat

class LetterListAdapter1(val data:ArrayList<Letter>, val answer:String, val context: Context): BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val generatedView = inflater.inflate(R.layout.letter, null)

        val letter = generatedView.findViewById<TextView>(R.id.textView6)

        letter.setBackgroundResource(R.color.background_strike)
        letter.setTextColor(ContextCompat.getColor(context, R.color.text_strike))
        letter.text = data[p0].letter.toString().uppercase()


        return generatedView

    }
}