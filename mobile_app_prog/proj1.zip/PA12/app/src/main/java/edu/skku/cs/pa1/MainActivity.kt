package edu.skku.cs.pa1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import java.io.InputStream
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputStream: InputStream = applicationContext.assets.open("wordle_words.txt")
        val wordsList = mutableListOf<String>()
        inputStream.bufferedReader().forEachLine { line ->
            wordsList.add(line)
        }

        val answer = chooseWord(wordsList)

        val words = ArrayList<Word>()
        val letters1 = ArrayList<Letter>()
        val letters2 = ArrayList<Letter>()
        val letters3 = ArrayList<Letter>()


        val btnActivity = findViewById<Button>(R.id.button)
        btnActivity.setOnClickListener {
            val editTextWord = findViewById<EditText>(R.id.editTextWord)

            if(!wordInDict(editTextWord, wordsList)) {
                Toast.makeText(
                    applicationContext,
                    "Word, ${editTextWord.text} not in dictionary!",
                    Toast.LENGTH_SHORT
                ).show()
            }
            //dict에 있는 경우
            else{
                val input = editTextWord.text.toString()
                words.add(Word(input))
                val wordListAdapter = WordListAdapter(words, answer, applicationContext)
                val wordListView = findViewById<ListView>(R.id.wordList)
                wordListView.adapter = wordListAdapter

                for(i in input.indices){
                    if(input[i] == answer[i]) {
                        letters1.add(Letter(input[i]))
                        val letterListAdapter1 = LetterListAdapter1(letters1, answer, applicationContext)
                        val letterListView1 = findViewById<ListView>(R.id.letterList1)
                        letterListView1.adapter = letterListAdapter1
                    }
                    else if(answer.contains(input[i])) {
                        letters2.add(Letter(input[i]))
                        val letterListAdapter2 = LetterListAdapter2(letters2, answer, applicationContext)
                        val letterListView2 = findViewById<ListView>(R.id.letterList2)
                        letterListView2.adapter = letterListAdapter2}

                    else {
                        letters3.add(Letter(input[i]))
                        val letterListAdapter3 = LetterListAdapter3(letters3, answer, applicationContext)
                        val letterListView3 = findViewById<ListView>(R.id.letterList3)
                        letterListView3.adapter = letterListAdapter3
                    }
                }
            }
        }
    }

    fun chooseWord(wordsList: List<String>): String {
        val randomIndex = Random.nextInt(wordsList.size) // 무작위 인덱스를 생성합니다.
        return wordsList[randomIndex] // 선택한 단어를 반환합니다.
    }

    fun wordInDict(editText: EditText, wordsList: List<String>): Boolean {
        val userInput = editText.text.toString().uppercase()
        return wordsList.any { it.uppercase() == userInput }
    }


}