package edu.skku.cs.pa3

data class Entry (
    val name : String? = null,
    val description : String? = null,
    val url : String?= null,
    val carlories: Double?= null
)