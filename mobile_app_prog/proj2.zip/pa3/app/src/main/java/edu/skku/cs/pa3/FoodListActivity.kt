package edu.skku.cs.pa3

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class FoodListActivity : AppCompatActivity() {
    private val clientID = "0f1091273912470599f57c8badf4bf6a"
    private val clientSecret = "718b896a09b2416ab7c828dda8e88717"
    private var accessToken: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_list)

        val kcal = intent.getStringExtra(MainActivity.KCAL)
        val tv = findViewById<TextView>(R.id.textView2)
        val btn = findViewById<Button>(R.id.searchBtn)

        tv.text = "${kcal} kcal"

        val et = findViewById<EditText>(R.id.foodInput)

        btn.setOnClickListener {
            // 액세스 토큰 요청
            val searchText = et.text.toString()

            requestAccessToken(searchText)
        }
    }
    private fun requestAccessToken(searchExpression: String) {
        val requestBody = FormBody.Builder()
            .add("grant_type", "client_credentials")
            .add("scope", "basic")
            .build()

        val request = Request.Builder()
            .url("https://oauth.fatsecret.com/connect/token")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Authorization", Credentials.basic(clientID, clientSecret))
            .post(requestBody)
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showToast("client ID 나 client Secret이 틀렸습니다.")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseJson = response.body?.string()
                response.body?.close()

                if (response.isSuccessful && responseJson != null) {
                    val accessToken = extractAccessToken(responseJson)
                    if (accessToken != null) {
                        getFoodData(accessToken, searchExpression)
                    } else {
                        showToast("client ID 나 client Secret이 틀렸습니다.")
                    }
                } else {
                    showToast("client ID 나 client Secret이 틀렸습니다.")
                }
            }
        })
    }

    private fun extractAccessToken(responseJson: String): String? {
        return try {
            val json = JSONObject(responseJson)
            json.getString("access_token")
        } catch (e: Exception) {
            null
        }
    }

    private fun getFoodData(accessToken: String, searchExpression: String) {
        val url = HttpUrl.Builder()
            .scheme("https")
            .host("platform.fatsecret.com")
            .addPathSegments("rest/server.api")
            .addQueryParameter("method", "foods.search")
            .addQueryParameter("search_expression", searchExpression)
            .addQueryParameter("format", "json")
            .addQueryParameter("max_results", "50")
            .build()

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showToast("찾고자 하는 음식이 없습니다.")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseJson = response.body?.string()
                response.body?.close()

                if (response.isSuccessful && responseJson != null) {
//                    val temp = findViewById<TextView>(R.id.temp)
//                    temp.text = responseJson
                   // val jsonArray = JSONArray(responseJson)
                    val json = JSONObject(responseJson)
                    val foodArray = json.getJSONObject("foods").getJSONArray("food")
                    val foods = ArrayList<Entry>()
                    runOnUiThread {
                        for (i in 0 until foodArray.length()) {
                            val food = foodArray.getJSONObject(i)
                            val name = food.getString("food_name")
                            val description = food.getString("food_description")
                            //description.find()

                            val url = food.getString("food_url")
                            foods.add(Entry(name, description, url))
                        }

                        val myAdapter = ListViewAdapter(foods, applicationContext)
                        val listView = findViewById<ListView>(R.id.foodsList)
                        listView.adapter = myAdapter

                        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->


                            // 선택된 아이템의 인덱스로부터 해당 항목의 food_url을 가져옴
                            val selectedFood = foodArray.getJSONObject(position)
                            val temp = selectedFood.getString("food_description")
                            val regex = Regex("(\\d+\\.?\\d*)kcal")
                            val matchResult = regex.find(temp)

                            var calories: Double? = null
                            matchResult?.let {
                                val caloriesText = it.groupValues[1]
                                calories = caloriesText.toDoubleOrNull()
                            }
                            val tv = findViewById<TextView>(R.id.textView2)
                            val kcal = tv.text.toString().replace(" kcal", "").toDouble()
                            val gap = kcal - calories!!
                            if(gap < 0){
                                showToast("해당 음식은 권장 칼로리를 초과합니다.")
                            }
                            else {
                                tv.text = gap.toString() + " kcal"

                                val foodUrl = selectedFood.getString("food_url")

                                val uri = Uri.parse(foodUrl)

                                // 브라우저로 해당 URL을 열기 위한 Intent 생성
                                val webIntent = Intent(Intent.ACTION_VIEW, uri)
                                startActivity(webIntent)
                            }
                        }

                    }

                } else {
                    showToast("검색어 오류")
                }
            }
        })
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }
}