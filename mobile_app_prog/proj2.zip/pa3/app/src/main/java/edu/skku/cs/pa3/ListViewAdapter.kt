package edu.skku.cs.pa3

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ListViewAdapter (val data: ArrayList<Entry>, val context : Context): BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]

    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.food_entry, null)

        val name_tv = view.findViewById<TextView>(R.id.textView)
        val description_tv = view.findViewById<TextView>(R.id.textView3)

        name_tv.text = data[p0].name.toString()
        description_tv.text = data[p0].description.toString()

        return view
    }

}