package edu.skku.cs.pa3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlin.math.round

class MainActivity : AppCompatActivity() {
    companion object{
        const val KCAL = "text"
    }

    private lateinit var radioMale: RadioButton
    private lateinit var radioFemale: RadioButton
    private lateinit var editAge: EditText
    private lateinit var editHeight: EditText
    private lateinit var editCurrentWeight: EditText
    private lateinit var editGoalWeight: EditText
    private lateinit var radioGroupActivity: RadioGroup
    private lateinit var btnNext: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val period = intent.getIntExtra("value",0)

        radioMale = findViewById<RadioButton>(R.id.radioMale)
        radioFemale = findViewById<RadioButton>(R.id.radioFemale)
        editAge = findViewById<EditText>(R.id.editAge)
        editHeight = findViewById<EditText>(R.id.editHeight)
        editCurrentWeight = findViewById<EditText>(R.id.editCurrentWeight)
        editGoalWeight = findViewById<EditText>(R.id.editGoalWeight)
        radioGroupActivity = findViewById<RadioGroup>(R.id.radioGroupActivity)
        btnNext = findViewById<Button>(R.id.button)

        btnNext.setOnClickListener {
            if (!validateInputs()) {
                Toast.makeText(
                    applicationContext,
                    "입력 정보를 다시 확인하세요.",
                    Toast.LENGTH_SHORT
                ).show()
            }

            val gender = if (radioMale.isChecked) "남성" else "여성"
            var age: Int = 0
            var height: Double = 0.0
            var currentWeight: Double = 0.0
            var goalWeight: Double = 0.0

            age = editAge.text.toString().trim().toInt()
            height = editHeight.text.toString().trim().toDouble()
            currentWeight = editCurrentWeight.text.toString().trim().toDouble()
            goalWeight = editGoalWeight.text.toString().trim().toDouble()

            var baseMetabolic: Double = 0.0


            //기초대사량 계산
            if (gender == "남성") {
                baseMetabolic = 88.4 + (13.4 * currentWeight) + (4.8 * height) - (5.68 * age)
            }
            else{
                baseMetabolic = 447.6 + (9.25 * currentWeight) + (3.1 * height) - (4.33 * age)
            }
            val activityPoint = mapOf(
                "거의 운동하지 않음" to 1.2,
                "가벼운 운동(주1~2일)" to 1.375,
                "보통 수준(주 3~4일)" to 1.55,
                "적극적으로 운동(주 5~6일)" to 1.725,
                "매우 적극적으로 운동(주 6~7일)" to 1.9
            )
            val selected = radioGroupActivity.checkedRadioButtonId
            val selectedActivity = findViewById<RadioButton>(selected)
            val activity = selectedActivity.text.toString()

            val point = activityPoint[activity] ?: 1.0

            //하루 감량 kcal 계산
            var kcalPerDAY = (goalWeight - currentWeight) / (period * 4) * 7000 / 7

            //대사량 계산
            val metabolic = baseMetabolic * point

            val eatPerDay = round(metabolic + kcalPerDAY)

            val intent = Intent(this, FoodListActivity::class.java).apply {
                putExtra(KCAL, eatPerDay.toString())
            }
            startActivity(intent)

        }




    }

    private fun validateInputs(): Boolean {
        if (!radioMale.isChecked && !radioFemale.isChecked) {
            return false
        }

        val age = editAge.text.toString().trim()
        if (age.isEmpty()) {
            return false
        }

        val height = editHeight.text.toString().trim()
        if (height.isEmpty()) {
            return false
        }

        val currentWeight = editCurrentWeight.text.toString().trim()
        if (currentWeight.isEmpty()) {
            return false
        }

        val goalWeight = editGoalWeight.text.toString().trim()
        if (goalWeight.isEmpty()) {
            return false
        }

        if (radioGroupActivity.checkedRadioButtonId == -1) {
            return false
        }

        return true
    }

}